from dominio.mesa import Mesa


class MesaService:

    def __init__(self, mesa_repository):
        self.mesa_repository = mesa_repository

    def cadastrar_mesa(self, numero):

        if numero <= 0:
            raise ValueError("Número inválido.")

        mesa = Mesa(
            id=None,
            numero=numero,
            status="Livre"
        )

        return self.mesa_repository.adicionar(mesa)

    def listar_mesas(self):

        return self.mesa_repository.listar()

    def atualizar_status(self, id_mesa, status):

        if id_mesa <= 0:
            raise ValueError("Mesa inválida.")

        if status not in ["Livre", "Ocupada"]:
            raise ValueError("Status inválido.")

        self.mesa_repository.atualizar_status(
            id_mesa,
            status
        )
        
    def listar_livres(self):

        return self.mesa_repository.listar_livres()
    
    def listar_ocupadas(self):

        return self.mesa_repository.listar_ocupadas()   
    
    
    def buscar_por_numero(self, numero):

        for mesa in self.mesa_repository.listar():

            if str(mesa.numero) == str(numero):

                return mesa

        return None
    
    def buscar_por_id(self, id_mesa):

        mesas = self.mesa_repository.listar()

        for mesa in mesas:

            if mesa.id == id_mesa:
                return mesa

        return None
    
