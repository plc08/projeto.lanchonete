from dominio.pagamento import Pagamento


class PagamentoService:

    def __init__(self, pagamento_repository):

        self.pagamento_repository = pagamento_repository

    def registrar_pagamento(

        self,

        pedido_id,

        valor,

        forma_pagamento,

        valor_recebido

    ):

        if pedido_id <= 0:

            raise ValueError("Pedido inválido.")

        if valor <= 0:

            raise ValueError("Valor inválido.")

        if forma_pagamento == "Dinheiro":

            if valor_recebido < valor:

                raise ValueError("Valor recebido insuficiente.")

        pagamento = Pagamento(

            id=None,

            pedido_id=pedido_id,

            valor=valor,

            forma_pagamento=forma_pagamento,

            valor_recebido=valor_recebido

        )

        return self.pagamento_repository.adicionar(
            pagamento
        )

    def calcular_troco(

        self,

        valor,

        valor_recebido

    ):

        return valor_recebido - valor

    def listar_pagamentos(self):

        return self.pagamento_repository.listar()