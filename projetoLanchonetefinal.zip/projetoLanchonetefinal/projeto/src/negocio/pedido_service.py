from dominio.pedido import Pedido


from dominio.pedido import Pedido


class PedidoService:

    STATUS_PENDENTE = "Pendente"
    STATUS_PREPARANDO = "Preparando"
    STATUS_PRONTO = "Pronto"
    STATUS_PAGO = "Pago"
    STATUS_CANCELADO = "Cancelado"
    STATUS_ENTREGUE = "Entregue"

    def __init__(self, pedido_repository):

        self.pedido_repository = pedido_repository

    # -------------------------------
    # Cadastro
    # -------------------------------

    def cadastrar_pedido(self, mesa_id):

        if mesa_id <= 0:
            raise ValueError("Mesa inválida.")

        pedido = Pedido(
            id=None,
            mesa_id=mesa_id,
            status=self.STATUS_PENDENTE
        )

        return self.pedido_repository.adicionar(
            pedido
        )

    # -------------------------------
    # Consultas
    # -------------------------------

    def listar_pedidos(self):

        return self.pedido_repository.listar()

    def buscar_por_id(self, id_pedido):

        if id_pedido <= 0:
            raise ValueError("Pedido inválido.")

        pedido = self.pedido_repository.buscar_por_id(
            id_pedido
        )

        if pedido is None:
            raise ValueError("Pedido não encontrado.")

        return pedido
    
    def buscar_pedido_aberto(self, mesa_id):

        return self.pedido_repository.buscar_pedido_aberto(
            mesa_id
        )

    # -------------------------------
    # Alteração de status
    # -------------------------------

    def atualizar_status(self, id_pedido, status):

        self.buscar_por_id(id_pedido)

        status_validos = [

            self.STATUS_PENDENTE,

            self.STATUS_PREPARANDO,

            self.STATUS_PRONTO,

            self.STATUS_PAGO,

            self.STATUS_CANCELADO,

            self.STATUS_ENTREGUE

        ]

        if status not in status_validos:
            raise ValueError("Status inválido.")

        self.pedido_repository.atualizar_status(
            id_pedido,
            status
        )

    # -------------------------------
    # Atalhos
    # -------------------------------

    def iniciar_preparo(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            self.STATUS_PREPARANDO
        )

    def marcar_pronto(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            self.STATUS_PRONTO
        )

    def marcar_pago(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            self.STATUS_PAGO
        )

    def cancelar_pedido(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            self.STATUS_CANCELADO
        )

    def entregar_pedido(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            self.STATUS_ENTREGUE
        )

    def remover_item(self, id_item):

        if id_item <= 0:
            raise ValueError("Item inválido.")

        self.item_repository.remover(id_item)


    def atualizar_quantidade(self, id_item, quantidade):

        if id_item <= 0:
            raise ValueError("Item inválido.")

        if quantidade <= 0:
            raise ValueError("Quantidade inválida.")

        self.item_repository.atualizar_quantidade(
            id_item,
            quantidade
        )