from dominio.usuario import Usuario


class UsuarioService:

    def __init__(self, usuario_repository):

        self.usuario_repository = usuario_repository

    # ----------------------------
    # Cadastro
    # ----------------------------

    def cadastrar_usuario(
        self,
        nome,
        login,
        senha,
        cargo
    ):

        if not nome.strip():
            raise ValueError("Nome obrigatório.")

        if not login.strip():
            raise ValueError("Login obrigatório.")

        if not senha.strip():
            raise ValueError("Senha obrigatória.")

        if cargo not in [
            "Gerente",
            "Garçom",
            "Caixa",
            "Cozinheiro"
        ]:
            raise ValueError("Cargo inválido.")

        usuario = Usuario(
            id=None,
            nome=nome,
            login=login,
            senha=senha,
            cargo=cargo,
            ativo=True
        )

        return self.usuario_repository.adicionar(
            usuario
        )

    # ----------------------------
    # Consultas
    # ----------------------------

    def listar_usuarios(self):

        return self.usuario_repository.listar()

    def buscar_usuario(self, id_usuario):

        usuario = self.usuario_repository.buscar_por_id(
            id_usuario
        )

        if usuario is None:
            raise ValueError("Usuário não encontrado.")

        return usuario

    # ----------------------------
    # Atualização
    # ----------------------------

    def editar_usuario(

        self,

        id_usuario,

        nome,

        login,

        senha,

        cargo,

        ativo

    ):

        usuario = Usuario(

            id=id_usuario,

            nome=nome,

            login=login,

            senha=senha,

            cargo=cargo,

            ativo=ativo

        )

        self.usuario_repository.atualizar(
            usuario
        )

    # ----------------------------
    # Desativação
    # ----------------------------

    def desativar_usuario(self, id_usuario):

        self.usuario_repository.desativar(
            id_usuario
        )

    # ----------------------------
    # Login
    # ----------------------------

    def autenticar(self, login, senha):

        usuario = self.usuario_repository.buscar_por_login(
            login
        )

        if usuario is None:
            raise ValueError("Usuário não encontrado.")

        if not usuario.ativo:
            raise ValueError("Usuário desativado.")

        if usuario.senha != senha:
            raise ValueError("Senha incorreta.")

        return usuario
    
