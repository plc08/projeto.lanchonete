from dados.conexao_singleton import ConexaoSingleton
from dominio.pedido import Pedido


class PedidoRepository:

    def __init__(self):
        self.conexao = ConexaoSingleton.get_conexao()

    def adicionar(self, pedido):

        cursor = self.conexao.cursor()

        sql = """
        INSERT INTO pedidos
        (mesa_id, status)
        VALUES (%s, %s)
        """

        cursor.execute(
            sql,
            (
                pedido.mesa_id,
                pedido.status
            )
        )

        self.conexao.commit()

        pedido.id = cursor.lastrowid

        cursor.close()

        return pedido

    def atualizar_status(self, id_pedido, novo_status):

        cursor = self.conexao.cursor()

        sql = """
        UPDATE pedidos
        SET status = %s
        WHERE id = %s
        """

        cursor.execute(
            sql,
            (
                novo_status,
                id_pedido
            )
        )

        self.conexao.commit()

        cursor.close()

    def listar(self):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            mesa_id,
            status
        FROM pedidos
        """

        cursor.execute(sql)

        resultados = cursor.fetchall()

        cursor.close()

        pedidos = []

        for resultado in resultados:

            pedidos.append(
                Pedido(
                    id=resultado[0],
                    mesa_id=resultado[1],
                    status=resultado[2]
                )
            )

        return pedidos

    def buscar_por_id(self, id_pedido):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            mesa_id,
            status
        FROM pedidos
        WHERE id = %s
        """

        cursor.execute(
            sql,
            (id_pedido,)
        )

        resultado = cursor.fetchone()

        cursor.close()

        if resultado is None:
            return None

        return Pedido(
            id=resultado[0],
            mesa_id=resultado[1],
            status=resultado[2]
        )
    
    def buscar_pedido_aberto(self, mesa_id):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            mesa_id,
            status
        FROM pedidos
        ORDER BY id
        WHERE mesa_id = %s
        AND status IN ('Pendente', 'Preparando')
        LIMIT 1
        """

        cursor.execute(sql, (mesa_id,))

        resultado = cursor.fetchone()

        cursor.close()

        if resultado is None:
            return None

        return Pedido(
            id=resultado[0],
            mesa_id=resultado[1],
            status=resultado[2]
        )
    
    def cancelar(self, id_pedido):

        self.atualizar_status(
            id_pedido,
            "Cancelado"
        )