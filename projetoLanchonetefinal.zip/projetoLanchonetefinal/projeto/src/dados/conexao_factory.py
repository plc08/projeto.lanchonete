import mysql.connector

# python -m pip install mysql-connector-python


class ConexaoFactory:

    @staticmethod
    def criar_conexao():

        conexao = mysql.connector.connect(
            host="localhost",
            user="root",
            password="P4022",
            database="lanchonete"
        )

        return conexao