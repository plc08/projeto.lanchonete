from dados.conexao_singleton import ConexaoSingleton
from dominio.mesa import Mesa


class MesaRepository:

    def __init__(self):
        self.conexao = ConexaoSingleton.get_conexao()

    def adicionar(self, mesa):

        cursor = self.conexao.cursor()

        sql = """
        INSERT INTO mesas
        (numero, status)
        VALUES (%s, %s)
        """

        cursor.execute(
            sql,
            (
                mesa.numero,
                mesa.status
            )
        )

        self.conexao.commit()

        mesa.id = cursor.lastrowid

        cursor.close()

        return mesa

    def listar(self):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            numero,
            status
        FROM mesas
        ORDER BY numero
        """

        cursor.execute(sql)

        resultados = cursor.fetchall()

        cursor.close()

        mesas = []

        for resultado in resultados:

            mesas.append(
                Mesa(
                    id=resultado[0],
                    numero=resultado[1],
                    status=resultado[2]
                )
            )

        return mesas

    def atualizar_status(self, id_mesa, status):

        cursor = self.conexao.cursor()

        sql = """
        UPDATE mesas
        SET status = %s
        WHERE id = %s
        """

        cursor.execute(
            sql,
            (
                status,
                id_mesa
            )
        )

        self.conexao.commit()

        cursor.close()

    def listar_livres(self):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            numero,
            status
        FROM mesas
        WHERE status='Livre'
        ORDER BY numero
        """

        cursor.execute(sql)

        resultados = cursor.fetchall()

        cursor.close()

        mesas = []

        for resultado in resultados:

            mesas.append(
                Mesa(
                    id=resultado[0],
                    numero=resultado[1],
                    status=resultado[2]
                )
            )

        return mesas
    
    def listar_ocupadas(self):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            numero,
            status
        FROM mesas
        WHERE status='Ocupada'
        ORDER BY numero
        """

        cursor.execute(sql)

        resultados = cursor.fetchall()

        cursor.close()

        mesas = []

        for resultado in resultados:

            mesas.append(
                Mesa(
                    id=resultado[0],
                    numero=resultado[1],
                    status=resultado[2]
                )
            )

        return mesas