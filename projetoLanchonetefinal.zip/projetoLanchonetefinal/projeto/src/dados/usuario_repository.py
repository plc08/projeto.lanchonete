from dominio.usuario import Usuario
from dados.conexao_singleton import ConexaoSingleton


class UsuarioRepository:

    def __init__(self):
        self.conexao = ConexaoSingleton.get_conexao()
        
    def adicionar(self, usuario):

        cursor = self.conexao.cursor()

        sql = """
        INSERT INTO usuarios
        (nome, login, senha, cargo, ativo)
        VALUES (%s, %s, %s, %s, %s)
        """

        cursor.execute(
            sql,
            (
                usuario.nome,
                usuario.login,
                usuario.senha,
                usuario.cargo,
                usuario.ativo
            )
        )

        self.conexao.commit()

        usuario.id = cursor.lastrowid

        cursor.close()

        return usuario

    def buscar_por_login(self, login):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            nome,
            login,
            senha,
            cargo,
            ativo
        FROM usuarios
        WHERE login = %s
        """

        cursor.execute(sql, (login,))

        resultado = cursor.fetchone()

        cursor.close()

        if resultado is None:
            return None

        return Usuario(
            id=resultado[0],
            nome=resultado[1],
            login=resultado[2],
            senha=resultado[3],
            cargo=resultado[4],
            ativo=resultado[5]
        )
    def quantidade_usuarios(self):

        cursor = self.conexao.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM usuarios"
        )

        quantidade = cursor.fetchone()[0]

        cursor.close()

        return quantidade
    
    def listar(self):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            nome,
            login,
            senha,
            cargo,
            ativo
        FROM usuarios
        ORDER BY nome
        """

        cursor.execute(sql)

        resultados = cursor.fetchall()

        cursor.close()

        usuarios = []

        for resultado in resultados:

            usuarios.append(
                Usuario(
                    id=resultado[0],
                    nome=resultado[1],
                    login=resultado[2],
                    senha=resultado[3],
                    cargo=resultado[4],
                    ativo=resultado[5]
                )
            )

        return usuarios
    
    def buscar_por_id(self, id_usuario):

        cursor = self.conexao.cursor()

        sql = """
        SELECT
            id,
            nome,
            login,
            senha,
            cargo,
            ativo
        FROM usuarios
        WHERE id=%s
        """

        cursor.execute(
            sql,
            (id_usuario,)
        )

        resultado = cursor.fetchone()

        cursor.close()

        if resultado is None:
            return None

        return Usuario(
            id=resultado[0],
            nome=resultado[1],
            login=resultado[2],
            senha=resultado[3],
            cargo=resultado[4],
            ativo=resultado[5]
        )
    
    def atualizar(self, usuario):

        cursor = self.conexao.cursor()

        sql = """
        UPDATE usuarios
        SET

            nome=%s,

            login=%s,

            senha=%s,

            cargo=%s,

            ativo=%s

        WHERE id=%s
        """

        cursor.execute(

            sql,

            (

                usuario.nome,

                usuario.login,

                usuario.senha,

                usuario.cargo,

                usuario.ativo,

                usuario.id

            )

        )

        self.conexao.commit()

        cursor.close()

    def listar(self):

        cursor = self.conexao.cursor()

        cursor.execute("""

            SELECT

                id,

                nome,

                login,

                cargo,

                ativo

            FROM usuarios

            ORDER BY nome

        """)

        usuarios = cursor.fetchall()

        cursor.close()

        return usuarios
    
    def desativar(self, id_usuario):

        cursor = self.conexao.cursor()

        cursor.execute(

            """

            UPDATE usuarios

            SET ativo = FALSE

            WHERE id=%s

            """,

            (id_usuario,)

        )

        self.conexao.commit()

        cursor.close()