class Mesa:
    def __init__(self, id, numero, status):
        self.id = id
        self.numero = numero
        self.status = status