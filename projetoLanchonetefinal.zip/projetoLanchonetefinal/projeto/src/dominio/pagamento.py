class Pagamento:

    def __init__(
        self,
        id,
        pedido_id,
        valor,
        forma_pagamento,
        valor_recebido
    ):

        self.id = id
        self.pedido_id = pedido_id
        self.valor = valor
        self.forma_pagamento = forma_pagamento
        self.valor_recebido = valor_recebido