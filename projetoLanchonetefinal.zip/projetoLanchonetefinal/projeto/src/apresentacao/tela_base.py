import customtkinter as ctk
from tkinter import messagebox

class TelaBase(ctk.CTkFrame):

    def __init__(self, master, usuario):

        super().__init__(master)

        self.master = master
        self.usuario = usuario

    # ------------------------------

    def criar_topo(self):

        topo = ctk.CTkFrame(self)

        topo.pack(
            fill="x",
            padx=10,
            pady=10
        )

        ctk.CTkLabel(
            topo,
            text=f"Usuário: {self.usuario.nome} | {self.usuario.cargo}",
            font=("Arial", 16, "bold")
        ).pack(
            side="left",
            padx=10
        )

        ctk.CTkButton(
            topo,
            text="Sair",
            width=100,
            command=self.sair
        ).pack(
            side="right",
            padx=10
        )

    # ------------------------------


    def mostrar_erro(self, mensagem):

        messagebox.showerror(
            "Erro",
            mensagem
        )

    # ------------------------------

    def mostrar_aviso(self, mensagem):

        messagebox.showwarning(
            "Aviso",
            mensagem
        )

    # ------------------------------

    def mostrar_sucesso(self, mensagem):

        messagebox.showinfo(
            "Sucesso",
            mensagem
        )

    # ------------------------------

    def sair(self):

        self.master.abrir_login()