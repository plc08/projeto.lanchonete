import customtkinter as ctk
from tkinter import ttk

from apresentacao.tela_base import TelaBase


class TelaCaixa(TelaBase):

    def __init__(self, master, usuario):

        super().__init__(master, usuario)

        self.pedido_service = master.pedido_service
        self.pagamento_service = master.pagamento_service
        self.item_service = master.item_service

        self.criar_interface()

        self.atualizar_pedidos()
    
    def criar_interface(self):

        self.criar_topo()

        container = ctk.CTkFrame(self)

        container.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        container.grid_columnconfigure(0, weight=3)
        container.grid_columnconfigure(1, weight=2)
        container.grid_rowconfigure(0, weight=1)

        frame_esquerda = ctk.CTkFrame(container)
        frame_esquerda.grid(
            row=0,
            column=0,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        frame_direita = ctk.CTkFrame(container)
        frame_direita.grid(
            row=0,
            column=1,
            padx=10,
            pady=10,
            sticky="nsew"
        )
        frame_esquerda.grid_rowconfigure(0, weight=1)
        frame_esquerda.grid_columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(

            frame_esquerda,

            columns=("id","mesa","status"),

            show="headings",

            height=8

        )

        self.tree.heading("id", text="Pedido")
        self.tree.heading("mesa", text="Mesa")
        self.tree.heading("status", text="Status")

        self.tree.grid(
            row=0,
            column=0,
            rowspan=6,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(

            frame_direita,

            text="Valor Recebido"

        ).pack(
            pady=(10, 5)
        )
        self.entry_valor = ctk.CTkEntry(frame_direita)

        self.entry_valor.pack(
            fill="x",
            padx=10,
            pady=5
        )

        self.label_total = ctk.CTkLabel(

            frame_direita,
            

            text="Total: R$ 0,00"

        )

        self.label_total.pack()

        ctk.CTkButton(

           

            frame_direita,

            text="Registrar Pagamento",

            command=self.registrar_pagamento

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

           

            frame_direita,
            text="Atualizar",

            command=self.atualizar_pedidos

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        self.tree.bind(

            "<<TreeviewSelect>>",

            self.selecionar_pedido

        )

    def atualizar_pedidos(self):

        self.tree.delete(
            *self.tree.get_children()
        )

        pedidos = self.pedido_service.listar_pedidos()

        for pedido in pedidos:

            self.tree.insert(

                "",

                "end",

                iid=pedido.id,

                values=(

                    pedido.id,

                    pedido.mesa_id,

                    pedido.status

                )

            )

    def selecionar_pedido(self, event=None):

        selecionado = self.tree.focus()

        if not selecionado:
            return

        self.pedido = self.pedido_service.pedido_repository.buscar_por_id(

            int(selecionado)

        )

        total = self.item_service.calcular_total(

            self.pedido.id

        )

        self.label_total.configure(

            text=f"Total: R$ {total:.2f}"

        )

    def registrar_pagamento(self):

        if not hasattr(self, "pedido"):

            self.mostrar_aviso(

                "Selecione um pedido."

            )

            return

        try:

            valor = float(

                self.entry_valor.get()

            )

        except ValueError:

            self.mostrar_aviso(

                "Valor inválido."

            )

            return

        self.pagamento_service.registrar_pagamento(

            self.pedido.id,

            valor

        )

        self.pedido_service.atualizar_status(

            self.pedido.id,

            "Pago"

        )

        self.mostrar_sucesso(

            "Pagamento registrado."

        )

        self.entry_valor.delete(
            0,
            "end"
        )

        self.label_total.configure(
            text="Total: R$ 0,00"
        )

        self.atualizar_pedidos()

   
        