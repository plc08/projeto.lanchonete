import customtkinter as ctk
from tkinter import ttk

from apresentacao.tela_base import TelaBase


class TelaCozinheiro(TelaBase):

    def __init__(self, master, usuario):

        super().__init__(master, usuario)

        self.pedido_service = master.pedido_service

        self.criar_interface()

        self.atualizar_pedidos()

    def criar_interface(self):

        self.criar_topo()

        container = ctk.CTkFrame(self)

        container.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        container.grid_columnconfigure(0, weight=3)
        container.grid_columnconfigure(1, weight=1)

        container.grid_rowconfigure(0, weight=1)

    

        frame_esquerda = ctk.CTkFrame(container)

        frame_esquerda.grid(
            row=0,
            column=0,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        frame_direita = ctk.CTkFrame(container)

        frame_direita.grid(
            row=0,
            column=1,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        self.tree = ttk.Treeview(
            frame_esquerda,

            columns=("id","mesa","status"),

            show="headings",

            height=10

        )

        self.tree.heading("id", text="Pedido")
        self.tree.heading("mesa", text="Mesa")
        self.tree.heading("status", text="Status")

        self.tree.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        ctk.CTkButton(

            self,

            text="Preparando",

            command=self.colocar_preparando

        ).pack(fill="x", padx=10, pady=5)

        ctk.CTkButton(

            self,

            text="Pronto",

            command=self.colocar_pronto

        ).pack(fill="x", padx=10, pady=5)

        ctk.CTkButton(

            self,

            text="Atualizar",

            command=self.atualizar_pedidos

        ).pack(fill="x", padx=10, pady=5)


    

    def atualizar_pedidos(self):

        self.tree.delete(
            *self.tree.get_children()
        )

        pedidos = self.pedido_service.listar_pedidos()

        for pedido in pedidos:

            self.tree.insert(

                "",

                "end",

                iid=pedido.id,

                values=(

                    pedido.id,

                    pedido.mesa_id,

                    pedido.status

                )

            )

    def colocar_preparando(self):

        selecionado = self.tree.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione um pedido."
            )

            return

        self.pedido_service.atualizar_status(

            int(selecionado),

            "Preparando"

        )

        self.atualizar_pedidos()

    def colocar_pronto(self):

        selecionado = self.tree.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione um pedido."
            )

            return

        self.pedido_service.atualizar_status(

            int(selecionado),

            "Pronto"

        )

        self.atualizar_pedidos()

    
   