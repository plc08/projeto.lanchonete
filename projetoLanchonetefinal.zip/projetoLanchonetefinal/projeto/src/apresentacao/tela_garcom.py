import customtkinter as ctk
from tkinter import ttk
from tkinter import messagebox

from apresentacao.tela_base import TelaBase


class TelaGarcom(TelaBase):

    def __init__(self, master, usuario):

      

        super().__init__(master, usuario)

        self.mesa_service = master.mesa_service
        self.produto_service = master.produto_service
        self.pedido_service = master.pedido_service
        self.item_service = master.item_service

        self.pedido_atual = None

        self.criar_interface()

        self.carregar_mesas()
        self.carregar_produtos()
        self.atualizar_pedidos()

    def criar_interface(self):

        self.criar_topo()

        container = ctk.CTkFrame(self)

        container.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        container.grid_columnconfigure(0, weight=1)
        container.grid_columnconfigure(1, weight=1)

        container.grid_rowconfigure(0, weight=1)
        container.grid_rowconfigure(1, weight=1)

        self.criar_painel_mesas(container)

        self.criar_painel_pedido(container)

        self.criar_painel_pedidos(container)

        self.criar_painel_itens(container)

   
        
    def criar_painel_mesas(self, container):
       
        frame = ctk.CTkFrame(container)
        frame.grid(
            row=0,
            column=0,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(

            frame,

            text="MESAS"

        ).pack(pady=5)

        self.tree_mesas = ttk.Treeview(

            frame,

            columns=("mesa", "status"),

            show="headings",

            height=5

        )

        self.tree_mesas.heading(
            "mesa",
            text="Mesa"
        )

        self.tree_mesas.heading(
            "status",
            text="Status"
        )

        self.tree_mesas.pack(
            fill="x",
            padx=10
        )

        ctk.CTkButton(

            frame,

            text="Ocupar Mesa",

            command=self.ocupar_mesa

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Desocupar Mesa",

            command=self.desocupar_mesa

        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )

    def criar_painel_pedido(self, container):

        frame = ctk.CTkFrame(container)

        frame.grid(
            row=0,
            column=1,
            padx=10,
            pady=10,
            sticky="nsew"
        )
        ctk.CTkLabel(
            frame,
            text="NOVO PEDIDO"
        ).pack(pady=5)

        ctk.CTkLabel(
            frame,
            text="Mesa"
        ).pack()

        self.combo_mesa = ctk.CTkComboBox(
            frame,
            values=[]
        )

        self.combo_mesa.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkLabel(
            frame,
            text="Produto"
        ).pack()

        self.combo_produto = ctk.CTkComboBox(
            frame,
            values=[]
        )

        self.combo_produto.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkLabel(
            frame,
            text="Quantidade"
        ).pack()

        self.entry_quantidade = ctk.CTkEntry(frame)

        self.entry_quantidade.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(
            frame,
            text="Novo Pedido",
            command=self.novo_pedido
        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(
            frame,
            text="Adicionar Produto",
            command=self.adicionar_item
        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )

        

        
    def criar_painel_itens(self, container):

        frame = ctk.CTkFrame(container)

        frame.grid(
            row=1,
            column=1,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(
            frame,
            text="ITENS DO PEDIDO"
        ).pack(pady=5)

        self.tree_itens = ttk.Treeview(

            frame,

            columns=("produto", "qtd", "subtotal"),

            show="headings",

            height=5

        )

        self.tree_itens.heading("produto", text="Produto")
        self.tree_itens.heading("qtd", text="Qtd")
        self.tree_itens.heading("subtotal", text="Subtotal")

        self.tree_itens.pack(
            fill="x",
            padx=10
        )

        self.label_total = ctk.CTkLabel(
            frame,
            text="Total: R$ 0,00"
        )

        self.label_total.pack(
            pady=10
        )
        ctk.CTkButton(

            frame,

            text="Alterar Quantidade",

            command=self.alterar_quantidade

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Remover Item",

            command=self.remover_item

        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )

    def criar_painel_pedidos(self, container):

        frame = ctk.CTkFrame(container)

        frame.grid(
            row=1,
            column=0,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(
            frame,
            text="PEDIDOS"
        ).pack(pady=5)

        self.tree_pedidos = ttk.Treeview(

            frame,

            columns=("id", "mesa", "status"),

            show="headings",

            height=6

        )

        self.tree_pedidos.heading("id", text="Pedido")
        self.tree_pedidos.heading("mesa", text="Mesa")
        self.tree_pedidos.heading("status", text="Status")

        self.tree_pedidos.pack(
            fill="both",
            expand=True,
            padx=10
        )

        ctk.CTkButton(

            frame,

            text="Atualizar",

            command=self.atualizar_pedidos

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Sair",

            command=self.sair

        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )

        self.tree_pedidos.bind(
            "<<TreeviewSelect>>",
            self.selecionar_pedido
        )

        
    def carregar_mesas(self):

        self.tree_mesas.delete(
            *self.tree_mesas.get_children()
        )

        mesas = self.mesa_service.listar_mesas()

        valores_combo = []

        for mesa in mesas:

            self.tree_mesas.insert(
                "",
                "end",
                iid=mesa.id,
                values=(
                    mesa.numero,
                    mesa.status
                )
            )

            if mesa.status == "Ocupada":

                valores_combo.append(
                    str(mesa.numero)
                )

        self.combo_mesa.configure(
            values=valores_combo
        )
        if valores_combo:
            self.combo_mesa.set("Selecione")

    def ocupar_mesa(self):

        selecionado = self.tree_mesas.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione uma mesa."
            )

            return

        self.mesa_service.atualizar_status(

            int(selecionado),

            "Ocupada"

        )

        self.carregar_mesas()
        self.atualizar_pedidos()

    def desocupar_mesa(self):

        selecionado = self.tree_mesas.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione uma mesa."
            )

            return

        self.mesa_service.atualizar_status(

            int(selecionado),

            "Livre"

        )

        self.carregar_mesas()

    def carregar_produtos(self):

        produtos = self.produto_service.listar_produtos()

        self.combo_produto.configure(

            values=[

                produto.nome

                for produto in produtos

            ]

        )
        self.combo_produto.set("Selecione")

    def novo_pedido(self):

        numero = self.combo_mesa.get()

        if numero == "":

            self.mostrar_aviso(
                "Selecione uma mesa."
            )

            return

        mesa = self.mesa_service.buscar_por_numero(
            numero
        )

        if pedido is None:

            pedido = self.pedido_service.cadastrar_pedido(
                mesa.id
            )

            self.mostrar_sucesso(
                "Pedido criado."
            )

        else:

            self.mostrar_sucesso(
                "Pedido carregado."
            )

        if pedido is None:

            pedido = self.pedido_service.cadastrar_pedido(
                mesa.id
            )

        self.pedido_atual = pedido

        self.carregar_itens()

        self.atualizar_pedidos()

        self.entry_quantidade.delete(0, "end")

        self.mostrar_sucesso(

            "Pedido criado com sucesso."

        )

    def adicionar_item(self):

        if self.pedido_atual is None:

            self.mostrar_aviso(
                "Selecione ou crie um pedido."
            )

            return

        if self.combo_produto.get() == "":

            self.mostrar_aviso(
                "Selecione um produto."
            )

            return

        try:

            quantidade = int(
                self.entry_quantidade.get()
            )

        except ValueError:

            self.mostrar_aviso(
                "Quantidade inválida."
            )

            return

        produto = self.produto_service.buscar_por_nome(

            self.combo_produto.get()

        )

        self.item_service.adicionar_item(

            self.pedido_atual.id,

            produto.id,

            quantidade

        )
       

        self.carregar_itens()
        self.atualizar_pedidos()

        self.entry_quantidade.delete(
            0,
            "end"
        )

    def carregar_itens(self):

        self.tree_itens.delete(
            *self.tree_itens.get_children()
        )

        if self.pedido_atual is None:
            return

       

        itens = self.item_service.listar_itens(
            self.pedido_atual.id
        )

        for item in itens:

            produto = self.produto_service.buscar_por_id(
                item.produto_id
            )

            subtotal = produto.preco * item.quantidade

            self.tree_itens.insert(

                "",

                "end",

                

                values=(

                    produto.nome,

                    item.quantidade,

                    f"R$ {subtotal:.2f}"

                )

            )

        total = self.item_service.calcular_total(
            self.pedido_atual.id
        )

        self.label_total.configure(
            text=f"Total: R$ {total:.2f}"
        )
    def atualizar_pedidos(self):

        self.tree_pedidos.delete(
            *self.tree_pedidos.get_children()
        )

        pedidos = self.pedido_service.listar_pedidos()

        for pedido in pedidos:

            mesa = self.mesa_service.buscar_por_id(
                pedido.mesa_id
            )

            numero = pedido.mesa_id

            if mesa:
                numero = mesa.numero

            self.tree_pedidos.insert(

                "",

                "end",

               

                values=(

                    pedido.id,

                    numero,

                    pedido.status

                )

            )

    def selecionar_pedido(self, event):

        selecionado = self.tree_pedidos.focus()

        if not selecionado:
            return

        pedido_id = self.tree_pedidos.item(
            selecionado
        )["values"][0]

        

        pedidos = self.pedido_service.listar_pedidos()

        for pedido in pedidos:

            if pedido.id == pedido_id:

                self.pedido_atual = pedido

                break

        self.carregar_itens()

    def atualizar_tela(self):

        self.carregar_mesas()

        self.carregar_produtos()

        self.atualizar_pedidos()

        if self.pedido_atual:

            self.carregar_itens()
    def cancelar_pedido(self):

        if self.pedido_atual is None:

            self.mostrar_aviso(
                "Selecione um pedido."
            )

            return

        self.pedido_service.cancelar_pedido(
            self.pedido_atual.id
        )

        mesa = self.mesa_service.buscar_por_id(
            self.pedido_atual.mesa_id
        )

        self.mesa_service.atualizar_status(
            mesa.id,
            "Livre"
        )

        self.pedido_atual = None

        self.carregar_mesas()
        self.atualizar_pedidos()
        self.carregar_itens()

        self.mostrar_sucesso(
            "Pedido cancelado."
        )
    def remover_item(self):

        selecionado = self.tree_itens.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione um item."
            )

            return

        self.item_service.remover(
            int(selecionado)
        )

        self.carregar_itens()
    def alterar_quantidade(self):

        selecionado = self.tree_itens.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione um item."
            )

            return

        try:

            quantidade = int(
                self.entry_quantidade.get()
            )

        except ValueError:

            self.mostrar_aviso(
                "Quantidade inválida."
            )

            return

        self.item_service.atualizar_quantidade(

            int(selecionado),

            quantidade

        )

        self.carregar_itens()
    
        
