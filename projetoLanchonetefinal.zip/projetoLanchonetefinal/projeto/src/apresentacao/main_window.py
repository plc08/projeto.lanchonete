import customtkinter as ctk

from apresentacao.tela_login import TelaLogin
from apresentacao.tela_garcom import TelaGarcom
from apresentacao.tela_cozinheiro import TelaCozinheiro
from apresentacao.tela_caixa import TelaCaixa
from apresentacao.tela_gerente import TelaGerente

from dados.usuario_repository import UsuarioRepository
from dados.mesa_repository import MesaRepository
from dados.produto_repository import ProdutoRepository
from dados.pedido_repository import PedidoRepository
from dados.item_pedido_repository import ItemPedidoRepository
from dados.pagamento_repository import PagamentoRepository

from negocio.login_service import LoginService
from negocio.usuario_service import UsuarioService
from negocio.mesa_service import MesaService
from negocio.produto_service import ProdutoService
from negocio.pedido_service import PedidoService
from negocio.item_pedido_service import ItemPedidoService
from negocio.pagamento_service import PagamentoService


class MainWindow(ctk.CTk):

    def __init__(self):

        super().__init__()

        self.title("Sistema da Lanchonete")

        self.geometry("1200x700")

        self.resizable(False, False)

        self.frame_atual = None

        self.criar_services()

        self.abrir_login()
        self.minsize(1200, 700)

    # =====================================================

    def criar_services(self):

        # Repositories

        self.usuario_repository = UsuarioRepository()

        self.mesa_repository = MesaRepository()

        self.produto_repository = ProdutoRepository()

        self.pedido_repository = PedidoRepository()

        self.item_repository = ItemPedidoRepository()

        self.pagamento_repository = PagamentoRepository()

        # Services

        self.login_service = LoginService(
            self.usuario_repository
        )

        self.usuario_service = UsuarioService(
            self.usuario_repository
        )

        self.mesa_service = MesaService(
            self.mesa_repository
        )

        self.produto_service = ProdutoService(
            self.produto_repository
        )

        self.pedido_service = PedidoService(
            self.pedido_repository
        )

        self.item_service = ItemPedidoService(
            self.item_repository,
            self.produto_repository
        )

        self.pagamento_service = PagamentoService(
            self.pagamento_repository
        )

    # =====================================================

    def trocar_tela(self, tela):

        if self.frame_atual is not None:

            self.frame_atual.destroy()

        self.frame_atual = tela

        self.frame_atual.pack(
            fill="both",
            expand=True
        )

    # =====================================================

    def abrir_login(self):

        self.trocar_tela(

            TelaLogin(self)

        )

    # =====================================================

    def abrir_sistema(self, usuario):

        cargo = usuario.cargo

        if cargo == "Garçom":

            self.trocar_tela(

                TelaGarcom(self, usuario)

            )

        elif cargo == "Cozinheiro":

            self.trocar_tela(

                TelaCozinheiro(self, usuario)

            )

        elif cargo == "Caixa":

            self.trocar_tela(

                TelaCaixa(self, usuario)

            )

        elif cargo == "Gerente":

            self.trocar_tela(

                TelaGerente(self, usuario)

            )