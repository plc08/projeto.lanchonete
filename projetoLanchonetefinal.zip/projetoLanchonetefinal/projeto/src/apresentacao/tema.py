import customtkinter as ctk

ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("blue")


class Tema:

    COR_FUNDO = "#F4F6F9"
    COR_MENU = "#1F2937"
    COR_CARD = "#FFFFFF"

    AZUL = "#2563EB"
    VERDE = "#16A34A"
    VERMELHO = "#DC2626"
    CINZA = "#6B7280"

    TEXTO = "#111827"
    TEXTO_CLARO = "#FFFFFF"

    FONTE = "Segoe UI"

    TITULO = (FONTE, 26, "bold")
    SUBTITULO = (FONTE, 18, "bold")
    TEXTO_NORMAL = (FONTE, 14)
    BOTAO = (FONTE, 15, "bold"),