import customtkinter as ctk
from tkinter import messagebox

from apresentacao.tema import Tema

from dados.usuario_repository import UsuarioRepository
from negocio.login_service import LoginService


class TelaLogin(ctk.CTkFrame):

    def __init__(self, master):

        super().__init__(master, fg_color=Tema.COR_FUNDO)

        self.master = master

        self.login_service = LoginService(
            UsuarioRepository()
        )

        self.criar_interface()

    def criar_interface(self):

        card = ctk.CTkFrame(
            self,
            width=420,
            height=420,
            corner_radius=15
        )

        card.place(
            relx=0.5,
            rely=0.5,
            anchor="center"
        )

        ctk.CTkLabel(
            card,
            text="Sistema da Lanchonete",
            font=Tema.TITULO
        ).pack(pady=(35,10))

        ctk.CTkLabel(
            card,
            text="Faça seu login",
            font=Tema.SUBTITULO
        ).pack(pady=(0,25))

        self.entry_login = ctk.CTkEntry(
            card,
            width=300,
            placeholder_text="Login"
        )

        self.entry_login.pack(pady=8)

        self.entry_senha = ctk.CTkEntry(
            card,
            width=300,
            placeholder_text="Senha",
            show="*"
        )

        self.entry_senha.pack(pady=8)

        self.entry_senha.bind(
            "<Return>",
            lambda e: self.entrar()
        )

        ctk.CTkButton(

            card,

            text="Entrar",

            width=300,

            command=self.entrar

        ).pack(pady=25)

    def entrar(self):

        try:

            usuario = self.login_service.autenticar(

                self.entry_login.get(),

                self.entry_senha.get()

            )

            self.master.abrir_sistema(usuario)

        except Exception as erro:

            messagebox.showerror(
                "Erro",
                str(erro)
            )