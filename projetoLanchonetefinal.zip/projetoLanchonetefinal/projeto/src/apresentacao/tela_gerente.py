import customtkinter as ctk
from tkinter import ttk

from apresentacao.tela_base import TelaBase


class TelaGerente(TelaBase):

    def __init__(self, master, usuario):

        super().__init__(master, usuario)

        self.usuario_service = master.usuario_service
        self.produto_service = master.produto_service

        self.criar_interface()
        self.carregar_usuarios()
        self.carregar_produtos()

       

    def criar_interface(self):

        ctk.CTkLabel(

            self,

            text="PAINEL DO GERENTE",

            font=("Arial",24,"bold")

        ).pack(pady=10)

        container = ctk.CTkFrame(self)

        container.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        container.grid_columnconfigure(0, weight=1)
        container.grid_columnconfigure(1, weight=1)
        self.criar_topo()
        self.criar_painel_usuarios(container)
        self.criar_painel_produtos(container)
        ctk.CTkButton(
            self,
            text="Sair",
            command=self.sair
        ).pack(
            fill="x",
            padx=10,
            pady=10
        )

        
    def criar_painel_usuarios(self, container):

        frame = ctk.CTkFrame(container)

        frame.grid(
            row=0,
            column=0,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(
            frame,
            text="USUÁRIOS"
        ).pack(pady=5)

        self.tree_usuarios = ttk.Treeview(

            frame,

            columns=("nome", "login", "cargo", "ativo"),

            show="headings",

            height=5

        )

        self.tree_usuarios.heading("nome", text="Nome")
        self.tree_usuarios.heading("login", text="Login")
        self.tree_usuarios.heading("cargo", text="Cargo")
        self.tree_usuarios.heading("ativo", text="Ativo")

        self.tree_usuarios.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkLabel(
            frame,
            text="Nome"
        ).pack()

        self.entry_nome = ctk.CTkEntry(frame)

        self.entry_nome.pack(
            fill="x",
            padx=10
        )

        ctk.CTkLabel(
            frame,
            text="Login"
        ).pack()

        self.entry_login = ctk.CTkEntry(frame)

        self.entry_login.pack(
            fill="x",
            padx=10
        )

        ctk.CTkLabel(
            frame,
            text="Senha"
        ).pack()

        self.entry_senha = ctk.CTkEntry(
            frame,
            show="*"
        )

        self.entry_senha.pack(
            fill="x",
            padx=10
        )

        ctk.CTkLabel(
            frame,
            text="Cargo"
        ).pack()

        self.combo_cargo = ctk.CTkComboBox(

            frame,

            values=[
                "Garçom",
                "Cozinheiro",
                "Caixa",
                "Gerente"
            ]

        )

        self.combo_cargo.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Cadastrar",

            command=self.cadastrar_usuario

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Desativar",

            command=self.desativar_usuario

        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )
    
    def carregar_usuarios(self):

        self.tree_usuarios.delete(
            *self.tree_usuarios.get_children()
        )

        usuarios = self.usuario_service.listar_usuarios()

        for usuario in usuarios:

            self.tree_usuarios.insert(

                "",

                "end",

                iid=usuario[0],

                values=(

                    usuario[1],

                    usuario[2],

                    usuario[3],

                    "Sim" if usuario[4] else "Não"

                )

            )

    def cadastrar_usuario(self):

        self.usuario_service.cadastrar_usuario(

            self.entry_nome.get(),

            self.entry_login.get(),

            self.entry_senha.get(),

            self.combo_cargo.get()

        )

        self.carregar_usuarios()

        self.entry_nome.delete(0, "end")
        self.entry_login.delete(0, "end")
        self.entry_senha.delete(0, "end")

        self.mostrar_sucesso(
            "Usuário cadastrado."
        )

    def desativar_usuario(self):

        selecionado = self.tree_usuarios.focus()

        if not selecionado:

            self.mostrar_aviso(
                "Selecione um usuário."
            )

            return

        self.usuario_service.desativar_usuario(

            int(selecionado)

        )

        self.carregar_usuarios()
    
    def criar_painel_produtos(self, container):

        frame = ctk.CTkFrame(container)

        frame.grid(
            row=0,
            column=1,
            padx=10,
            pady=10,
            sticky="nsew"
        )

        ctk.CTkLabel(

            frame,

            text="PRODUTOS"

        ).pack(pady=5)

        self.tree_produtos = ttk.Treeview(

            frame,

            columns=("nome","preco"),

            show="headings",

            height=6

        )

        self.tree_produtos.heading(

            "nome",

            text="Nome"

        )

        self.tree_produtos.heading(

            "preco",

            text="Preço"

        )

        self.tree_produtos.pack(

            fill="x",

            padx=10,

            pady=5

        )

        ctk.CTkLabel(
            frame,
            text="Nome"
        ).pack()

        self.entry_produto = ctk.CTkEntry(frame)

        self.entry_produto.pack(
            fill="x",
            padx=10
        )

        ctk.CTkLabel(
            frame,
            text="Preço"
        ).pack()

        self.entry_preco = ctk.CTkEntry(frame)

        self.entry_preco.pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Cadastrar",

            command=self.cadastrar_produto

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Editar",

            command=self.editar_produto

        ).pack(
            fill="x",
            padx=10,
            pady=5
        )

        ctk.CTkButton(

            frame,

            text="Excluir",

            command=self.excluir_produto

        ).pack(
            fill="x",
            padx=10,
            pady=(0,10)
        )
        
    def carregar_produtos(self):

        self.tree_produtos.delete(
            *self.tree_produtos.get_children()
        )

        produtos = self.produto_service.listar_produtos()

        for produto in produtos:

            self.tree_produtos.insert(

                "",

                "end",

                iid=produto.id,

                values=(

                    produto.nome,

                    f"R$ {produto.preco:.2f}"

                )

            )

    def cadastrar_produto(self):

        self.produto_service.cadastrar_produto(

            self.entry_produto.get(),

            float(

                self.entry_preco.get()

            )

        )

        self.carregar_produtos()

        self.entry_produto.delete(
            0,
            "end"
        )

        self.entry_preco.delete(
            0,
            "end"
        )

        self.mostrar_sucesso(

            "Produto cadastrado."

        )

    def editar_produto(self):

        selecionado = self.tree_produtos.focus()

        if not selecionado:

            self.mostrar_aviso(

                "Selecione um produto."

            )

            return

        self.produto_service.atualizar_produto(

            int(selecionado),

            self.entry_produto.get(),

            float(

                self.entry_preco.get()

            )

        )

        self.carregar_produtos()

    def excluir_produto(self):

        selecionado = self.tree_produtos.focus()

        if not selecionado:

            self.mostrar_aviso(

                "Selecione um produto."

            )

            return

        self.produto_service.remover_produto(

            int(selecionado)

        )

        self.carregar_produtos()
   
    
        