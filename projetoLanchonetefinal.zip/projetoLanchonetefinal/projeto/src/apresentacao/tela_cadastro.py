import customtkinter as ctk
from tkinter import messagebox

from dados.usuario_repository import UsuarioRepository
from negocio.usuario_service import UsuarioService


class TelaCadastroInicial(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("Primeiro acesso")
        self.geometry("420x470")

        self.repository = UsuarioRepository()
        self.service = UsuarioService(self.repository)

        self.criar_componentes()

    def criar_componentes(self):

        ctk.CTkLabel(
            self,
            text="Primeiro Acesso",
            font=("Arial", 28, "bold")
        ).pack(pady=20)

        ctk.CTkLabel(
            self,
            text="Cadastre o gerente do sistema"
        ).pack()

        ctk.CTkLabel(self, text="Nome").pack(pady=(20,5))

        self.nome = ctk.CTkEntry(
            self,
            width=260
        )

        self.nome.pack()

        ctk.CTkLabel(self, text="Login").pack(pady=(15,5))

        self.login = ctk.CTkEntry(
            self,
            width=260
        )

        self.login.pack()

        ctk.CTkLabel(self, text="Senha").pack(pady=(15,5))

        self.senha = ctk.CTkEntry(
            self,
            width=260,
            show="*"
        )

        self.senha.pack()

        ctk.CTkButton(
            self,
            text="Cadastrar Gerente",
            command=self.cadastrar
        ).pack(pady=30)

    def cadastrar(self):

        try:

            self.service.cadastrar_usuario(
                self.nome.get(),
                self.login.get(),
                self.senha.get(),
                "Gerente"
            )

            messagebox.showinfo(
                "Sucesso",
                "Gerente cadastrado."
            )

            self.destroy()

            from apresentacao.tela_login import TelaLogin

            TelaLogin().mainloop()

        except Exception as erro:

            messagebox.showerror(
                "Erro",
                str(erro)
            )