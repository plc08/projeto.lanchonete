DROP DATABASE IF EXISTS lanchonete;

CREATE DATABASE lanchonete;

USE lanchonete;


-- USUÁRIOS


CREATE TABLE usuarios (

    id INT AUTO_INCREMENT PRIMARY KEY,

    nome VARCHAR(100) NOT NULL,

    login VARCHAR(50) NOT NULL UNIQUE,

    senha VARCHAR(50) NOT NULL,

    cargo ENUM(
        'Gerente',
        'Garçom',
        'Cozinheiro',
        'Caixa'
    ) NOT NULL,

    ativo BOOLEAN DEFAULT TRUE

);


-- MESAS


CREATE TABLE mesas (

    id INT AUTO_INCREMENT PRIMARY KEY,

    numero INT NOT NULL UNIQUE,

    status ENUM(
        'Livre',
        'Ocupada'
    ) DEFAULT 'Livre'

);


-- PRODUTOS


CREATE TABLE produtos (

    id INT AUTO_INCREMENT PRIMARY KEY,

    nome VARCHAR(100) NOT NULL,

    preco DECIMAL(10,2) NOT NULL

);


-- PEDIDOS


CREATE TABLE pedidos (

    id INT AUTO_INCREMENT PRIMARY KEY,

    mesa_id INT NOT NULL,

    status ENUM(

        'Pendente',

        'Preparando',

        'Pronto',

        'Pago'

    ) DEFAULT 'Pendente',

    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (mesa_id)
        REFERENCES mesas(id)

);


-- ITENS DO PEDIDO


CREATE TABLE itens_pedido (

    id INT AUTO_INCREMENT PRIMARY KEY,

    pedido_id INT NOT NULL,

    produto_id INT NOT NULL,

    quantidade INT NOT NULL,

    FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id),

    FOREIGN KEY (produto_id)
        REFERENCES produtos(id)

);


-- PAGAMENTOS


CREATE TABLE pagamentos (

    id INT AUTO_INCREMENT PRIMARY KEY,

    pedido_id INT NOT NULL,

    valor DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id)

);


-- USUÁRIOS


INSERT INTO usuarios
(nome,login,senha,cargo,ativo)
VALUES

('Administrador','pedro','123','Gerente',TRUE),

('Léo','leo','123','Garçom',TRUE),

('Nicolle','nicolle','123','Cozinheiro',TRUE),

('Keylly','keylly','123','Caixa',TRUE);


-- MESAS


INSERT INTO mesas
(numero,status)
VALUES

(1,'Livre'),
(2,'Livre'),
(3,'Livre'),
(4,'Livre'),
(5,'Livre'),
(6,'Livre'),
(7,'Livre'),
(8,'Livre'),
(9,'Livre'),
(10,'Livre');


-- PRODUTOS


INSERT INTO produtos
(nome,preco)
VALUES

('X-Burguer',18.00),

('X-Salada',20.00),

('X-Bacon',23.00),

('Cachorro Quente',15.00),

('Batata Frita',12.00),

('Refrigerante Lata',6.00),

('Suco Natural',8.00),

('Água Mineral',4.00),

('Milk Shake',14.00);